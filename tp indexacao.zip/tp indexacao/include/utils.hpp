#ifndef __UTILS_HPP__
#define __UTILS_HPP__

#include <string>
#include <algorithm>

using namespace std;

class Utils
{
	public:
		Utils();
		static string removerAcentos(string str);
};

#endif