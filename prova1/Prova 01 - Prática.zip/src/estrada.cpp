#include <random>

#include "estrada.h"


Estrada::Estrada(
  unsigned int num_linhas,
  unsigned int num_colunas,
  unsigned int taxa_carros,
  Sapo &sapo
): _sapo(sapo) {
  _num_linhas = num_linhas;
  _num_colunas = num_colunas;
  _taxa_carros = taxa_carros;
  _turno = 0;
  _gera_rand.seed(30091985);
}

bool Estrada::atualiza(MovimentoSapo movimento) {
  
  // [AVISO] as linhas abaixo geram carros aleatórios
  
  std::uniform_int_distribution<int> ldist(0, _num_linhas);
  std::uniform_int_distribution<int> cdist(0, 1);
  std::uniform_int_distribution<int> vdist(0, _num_colunas / 5);

  if (_turno % _taxa_carros == 0) {
    //unsigned int linha_carro = ldist(_gera_rand);
   unsigned int col_carro = cdist(_gera_rand);
   // unsigned int velocidade = vdist(_gera_rand);
    if (col_carro == 1) {
      col_carro = _num_colunas - 1;
    }

    // [TODO!] Um novo carro deve ser alocado aqui.
  }

  // [TODO!] seu código aqui!
  // Garanque os carros andem
  // Garanta que o sapo anda
  // Garanta que carros que saiem da tela são desalocados.

  _turno++;
  return false; // [TODO!] isso deve mudar se o sapo andar até o fim
}

std::set<Carro *> Estrada::get_carros() {
  return _carros;
}

unsigned int Estrada::get_num_colunas() {
  return _num_colunas;
}

unsigned int Estrada::get_num_linhas() {
  return _num_linhas;
}