Lampada lp; // a

Lampada *lp; // a

Lampada lp(); // a 

Lampada lp(30) // b

Lampada lp(13.50) // nenhum

Lampada lp(30, 13.50) // c

int x = 60;
Lampada lp(x); // b