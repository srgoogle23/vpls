Produto p3(1301, "Celular", 1280.99, 60);
p3.imprime();
pel->comprar_garantia(120);